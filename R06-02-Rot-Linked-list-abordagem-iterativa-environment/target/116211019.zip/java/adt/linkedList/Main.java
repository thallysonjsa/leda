package adt.linkedList;

public class Main {

	public static void main(String[] args) {
		DoubleLinkedListImpl<Integer> list = new DoubleLinkedListImpl<>();
		list.insert(1);
		list.insert(2);
		list.insert(3);
		list.insert(4);
		list.insert(5);
		System.out.println(list.getLast());
		list.remove(5);
		System.out.println(list.getLast());
	}

}
